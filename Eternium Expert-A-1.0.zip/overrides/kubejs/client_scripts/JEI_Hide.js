// priority: 0

JEIEvents.hideItems(event => {
	// Hide items in JEI here
	// event.hide('minecraft:cobblestone')

	event.hide('avaritia:iron_singularity')
	event.hide('avaritia:golden_singularity')
	event.hide('avaritia:lapis_singularity')
	event.hide('avaritia:redstone_singularity')
	event.hide('avaritia:nether_quartz_singularity')
	event.hide('avaritia:diamond_singularity')
	event.hide('avaritia:emerald_singularity')
	event.hide('avaritia:neutronium_compressor')
	event.hide('avaritia:extreme_crafting_table')
	event.hide('ae2:facade')
	event.hide('mysticalagriculture:ruby_essence')
	event.hide('mysticalagriculture:ruby_seeds')
	event.hide('chicken_roost:a_chicken_ruby_spawn_egg')
	event.hide('chicken_roost:echickenruby')
	event.hide('mysticalagriculture:sapphire_essence')
	event.hide('mysticalagriculture:sapphire_seeds')
	event.hide('chicken_roost:a_chicken_sapphire_spawn_egg')
	event.hide('chicken_roost:echickensapphire')
})
